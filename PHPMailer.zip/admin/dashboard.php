<?php require('Common/Header.php') ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="row">

        

    </div>
</div>

<?php require('Common/Footer.php') ?>


</body>

</html>